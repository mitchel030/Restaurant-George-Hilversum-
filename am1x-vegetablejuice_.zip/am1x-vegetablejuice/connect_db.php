<?php
	$fullname = $_POST['fullname'];
	$selectaday = $_POST['selectaday'];
    $availabletime = $_POST['availabletime'];
	$phonenumber = $_POST['phonenumber'];
	$amountofguests = $_POST['amountofguests'];

	// Database connection
	$conn = new mysqli('localhost','root','','test');
	if($conn->connect_error){
		echo "$conn->connect_error";
		die("Connection Failed : ". $conn->connect_error);
	} else {
		$stmt = $conn->prepare("insert into registration(fullname, selectadya, availabletime, phonenumber,amountofguests) values(?, ?, ?, ?, ?, ?)");
		$stmt->bind_param("si", $fullname, $selectaday, $availabletime, $phonenumber, $amountofguests,);
		$execval = $stmt->execute();
		echo $execval;
		echo "successfully booked";
		$stmt->close();
		$conn->close();
	}
?>