<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-F3w7mX95PdgyTmZZMECAngseQB83DfGTowi0iMjiWaeVhAn4FJkqJByhZMI3AhiU" crossorigin="anonymous">
    <link href="https://fonts.googleapis.com/css2?family=Poppins&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
    <title>Hello, world!</title>
  </head>

  <body>
    <!-- Header-->
    <header class="py-5" style="background-color: rgb(255, 255, 255);">
        <div class="container px-4 px-lg-5">
            <img src="./img/logogeorgemarina.png" class="rounded mx-auto d-block" alt="...">
        </div>
    </header>

    <div class="container">       

      <!-- plattegrond -->
      <div class="row">
        <div class="col-md-9 text-center d-none d-md-block">
          <img src="./img/plattegrond.svg" class="img-fluid" alt=". . ." style="width: 56%; padding: 1%;">
        
          <!-- 6persoontafels-->
        <button type="button" class="btn btn-outline-dark btn-sm" style= "position:relative; top: -32%; left: -51%; width:2.5%; height: 11%;"></button>
        <button type="button" class="btn btn-outline-dark btn-sm" style= "position:relative; top: -18.4%; left: -54%; width:2.5%; height: 11%;"></button>
        <button type="button" class="btn btn-outline-dark btn-sm" style= "position:relative; top: -4.4%; left: -57%; width:2.5%; height: 11%;"></button>
        <button type="button" class="btn btn-outline-dark btn-sm" style= "position:relative; top: 9.6%; left: -60%; width:2.5%; height: 11%;"></button>

          <!-- 4persoontafels -->
        <button type="button" class="btn btn-outline-dark" style= "position:relative; top: -38.4%; left: -27%; width:4.5%; height: 5.6%;"></button>
        <button type="button" class="btn btn-outline-dark" style= "position:relative; top: -26.5%; left: -26%; width:4.5%; height: 5.6%;"></button>
        <button type="button" class="btn btn-outline-dark" style= "position:relative; top: -15%; left: -37%; width:4.5%; height: 5.6%;"></button>
        <button type="button" class="btn btn-outline-dark" style= "position:relative; top: -3%; left: -36%; width:4.5%; height: 5.6%;"></button>
        <button type="button" class="btn btn-outline-dark" style= "position:relative; top: 8.5%; left: -47.5%; width:4.5%; height: 5.6%;"></button>
        <button type="button" class="btn btn-outline-dark" style= "position:relative; top: 8.5%; left: -74.5%; width:4.5%; height: 5.6%;"></button>

          <!-- bar links verticaal -->
        <button type="button" class="btn btn-outline-dark" style= "position:relative; top: -84%; left: -9.4%; width:1.8%; height: 3.1%;"></button>
        <button type="button" class="btn btn-outline-dark" style= "position:relative; top: -80.3%; left: -12.5%; width:1.8%; height: 3.1%;"></button>
        <button type="button" class="btn btn-outline-dark" style= "position:relative; top: -76.7%; left: -15.7%; width:1.8%; height: 3.1%;"></button>
        <button type="button" class="btn btn-outline-dark" style= "position:relative; top: -72.8%; left: -18.8%; width:1.8%; height: 3.1%;"></button>
        <button type="button" class="btn btn-outline-dark" style= "position:relative; top: -69%; left: -22%; width:1.8%; height: 3.1%;"></button>
        <button type="button" class="btn btn-outline-dark" style= "position:relative; top: -65.3%; left: -25%; width:1.8%; height: 3.1%;"></button>
        <button type="button" class="btn btn-outline-dark" style= "position:relative; top: -61.4%; left: -28.2%; width:1.8%; height: 3.1%;"></button>

        <!-- bar horizontaal -->
        <button type="button" class="btn btn-outline-dark" style= "position:fixed; top: -50%; left: -34%; width:1.5%; height: 3.6%;"></button>
        <button type="button" class="btn btn-outline-dark" style= "position:fixed; top: -57%; left: -34%; width:1.5%; height: 3.6%;"></button>
        <button type="button" class="btn btn-outline-dark" style= "position:fixed; top: -57%; left: -34%; width:1.5%; height: 3.6%;"></button>
        <button type="button" class="btn btn-outline-dark" style= "position:fixed; top: -57%; left: -34%; width:1.4%; height: 3.6%;"></button>

        <!-- bar rechts verticaal -->
        <button type="button" class="btn btn-outline-dark" style= "position:relative; top: -84%; left: -18%; width:1.8%; height: 3.1%;"></button>
        <button type="button" class="btn btn-outline-dark" style= "position:relative; top: -80%; left: -21%; width:1.5%; height: 3.1%;"></button>
        <button type="button" class="btn btn-outline-dark" style= "position:relative; top: -76.5%; left: -24.2%; width:1.5%; height: 3.1%;"></button>
        <button type="button" class="btn btn-outline-dark" style= "position:relative; top: -72.6%; left: -27.3%; width:1.5%; height: 3.1%;"></button>
        <button type="button" class="btn btn-outline-dark" style= "position:relative; top: -69%; left: -30.5%; width:1.5%; height: 3.1%;"></button>
        <button type="button" class="btn btn-outline-dark" style= "position:relative; top: -65%; left: -33.6%; width:1.5%; height: 3.1%;"></button>
        <button type="button" class="btn btn-outline-dark" style= "position:relative; top: -61%; left: -36.8%; width:1.5%; height: 3.1%;"></button>
        </div>
      </div>         

      <!--reserveren-->

            <div class="row justify-content" style="position:absolute; top: 400px; left: 1000px; width:100%;">
            <form action="process.php" method="post">
                <div class="col-md-3">
                <div class="form-group">
                    <input type="fullname" class="form-control" id="fullname" name="fullname" aria-describedby="fullnamenameHelp" placeholder="fullname">
                </div>
                </div>
            </form>
            <ul class="list-group list-group-flush">
                <li class="list-group-item" style="font-weight: bold;"> </li>
            </ul>

            <ul class="list-group list-group-flush">
                <li class="list-group-item" style="font-weight: bold;"> </li>
            </ul>
            <form action="process.php" method="post">
                <div class="form-group">
                    <div class="col-md-3">
                    <input type="email" class="form-control" id="email" name="email" aria-describedby="emailHelp" placeholder="Email">
                    </div>
                </div>
            </form>
            <ul class="list-group list-group-flush">
                <li class="list-group-item" style="font-weight: bold;"> </li>
            </ul>
            <form action="process.php" method="post">
                <div class="form-group">
                    <div class="col-md-3">
                    <input type="phonenumber" class="form-control" id="phonenumber" name="phonenumber" aria-describedby="phonenumberHelp" placeholder="Phonenumber">
                    </div>
                </div>
            </form>
            <ul class="list-group list-group-flush">
                <li class="list-group-item" style="font-weight: bold;"> </li>
            </ul>
            <div class="btn-group" action="process.php" method="post">
                <div class="col-md-3">
                <button class="btn btn-dark btn-ml dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false" name="amountofguests" id="amountofguests">
                    Amount of guests
                </button>
                <ul class="dropdown-menu">
                    <li><a class="dropdown-item" href="#">1</a></li>
                    <li><a class="dropdown-item" href="#">2</a></li>
                    <li><a class="dropdown-item" href="#">3</a></li>
                    <li><a class="dropdown-item" href="#">4</a></li>
                    <li><a class="dropdown-item" href="#">5</a></li>
                    <li><a class="dropdown-item" href="#">6</a></li>
                    </ul>
                </div>
            </div>
            <ul class="list-group list-group-flush">
                <li class="list-group-item" style="font-weight: bold;"> </li>
            </ul>

            <!--select a date -->
            <div class="form-group" action="process.php" method="post">
                <div class="col-md-1">
                <label for="exampleFormControlSelect1"></label>
                <select class="form-control" id="selectadate" name="selectadate">
                <option>select a date</option>
                <option>october 3rd</option>
                <option>october 4th</option>
                <option>october 5th</option>
                <option>october 6th</option>
                </select>
            </div>

            <!-- select time -->
            <div class="form-group" action="process.php" method="post">
                <div class="col-md-1">
                <label for="exampleFormControlSelect2"></label>
                <select class="form-control" id="availabletime" name="availabletime">
                <option>available times</option>
                <option>18:30</option>
                <option>18:45</option>
                <option>19:00</option>
                <option>20:00</option>
                <option>20:15</option>
                <option>20:30</option>
                <option>20:45</option>
                <option>21:00</option>
                </select>
                </div>
                </div>
            </div>

            <form>
                <div class="form-group" action="process.php" method="post">
                    <div class="col-md-3">
                    <input type="specialwishes" class="form-control" name="specialwishes" id="specialwishes" aria-describedby="specialwishesHelp" placeholder="Special wishes">
                    </div>
                </div>
            </form>
            <div class="card p-3 mb-2 bg-light text-dark" style="width: 18rem; left: 12px;">
                    <a class="btn btn-light btn-ml btn btn-outline-dark" role="button" type="submit" id="btn" value="login">Book!</a>
                    </p>
                </div>
                
          </div>
      </div>

    </div>