<?php
    //get values from reserveren.html
    $fullname = $_POST['fullname'];
    $email = $_POST['email'];
    $phonenumber = $_POST['phonenumber'];
    $amountofguests = $_POST['amountofguests'];
    $selectadate = $_POST['selectadate'];
    $availabletime = $_POST['availabletime'];
    $specialwishes = $_POST['specialwishes'];

    //connect to server and select database
    mysql_connect("localhost", "noor", "nwKCTGkIhh60VQ2m");
    mysql_select_db("georgemarina");

    //query db for user
    $result = mysql_query("select * from users where fullname = '$fullname' , email = '$email' , 
            phonenumber = '$phonenumber' , amountofguests = '$amountofguests' , 
            selectadate = '$selectadate' , availabletime = '$availabletime' 
            and specialwishes = '$specialwishes'")
            or die("failed to query database" .mysql_error());
    $row = mysql_fetch_array($result);
    if ($row['fullname'] == $fullname && $row['email'] == $email &&
        $row['phonenumber'] == $phonenumber && $row['amountofguests'] == $amountofguests &&
        $row['selectdate'] == $selectdate && $row['availabletime'] == $availabletime &&
        $row['specialwishes'] == $specialwishes){
        echo "thank you for booking at georgemarina";
    } else {
        echo "failed";
    }
    ?>