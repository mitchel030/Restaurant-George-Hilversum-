<?php
    include 'connect_db.php';


    var_dump($_POST); die();

    $fullname = $_POST['fullname'];
    $phonenumber = $_POST['phonenumber'];
    $email = $_POST['email'];
    $inputdate = $_POST['inputdate'];
    $availabletime = $_POST['availabletime'];
    $specialwishes = $_POST['specialwishes'];
  
    $sql = "INSERT INTO `booking2` (`fullname`, 
                                `phonenumber`, 
                                `email`, 
                                `inputdate`, 
                                `availabletime`, 
                                `specialwishes`)
            VALUES              ('$fullname', 
                                '$phonenumber', 
                                '$email', 
                                '$inputdate', 
                                '$availabletime', 
                                '$specialwishes')";

    
    mysqli_query($conn, $sql);

    var_dump($sql); exit;
?>