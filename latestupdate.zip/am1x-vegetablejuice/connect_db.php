<?php
$fullname = filter_input(INPUT_POST, 'fullname');
$email = filter_input(INPUT_POST, 'email');
$phonenumber = filter_input(INPUT_POST, 'phonenumber');
$inputdate = filter_input(INPUT_POST, 'inputdate');
$availabletime = filter_input(INPUT_POST, 'availabletime');
$specialwishes = filter_input(INPUT_POST, 'specialwishes');
if (!empty($fullname)){
if (!empty($email)){
if (!empty($phonenumber)){
if (!empty($inputdate)){
if (!empty($availabletime)){
if (!empty($specialwishes)){

$host = "localhost";
$dbusername = "root";
$dbpassword = "";
$dbname = "georgehilversum";
// Create connection
$conn = new mysqli ($host, $dbusername, $dbpassword, $dbname);
if (mysqli_connect_error()){
die('Connect Error ('. mysqli_connect_errno() .') '
. mysqli_connect_error());
}
else{
$sql = "INSERT INTO `bookings` (fullname, email, phonenumber, inputdate, availabletime, specialwishes)
values ('$fullname','$email', '$phonenumber', '$inputdate', '$availabletime', '$specialwishes')";
if ($conn->query($sql)){
echo "booking succesfull";
}
else{
echo "Error: ". $sql ."
". $conn->error;
}
$conn->close();
}
}
else{
echo "email should not be empty";
die();
}
}
else{
echo "fullname should not be empty";
die();
}
}
}
}
}
    //email verzenden
    if (new mysqli($conn, $sql)){
        $to = $email;
        $subject = "Reservation at George Marina Hilversum";
        $message = "Dear guest,\r\n
Your reservation at George Marina is all set.\r\n
\r\n
Check the information you provided and feel free to contact us if anything is incorrect.\r\n
Name: $fullname\r\n
Phonenumber: $phonenumber\r\n
Resevation date: $inputdate\r\n
Time: $availabletime\r\n
Something we'll think about: $specialwishes\r\n
\r\n
Bon Appetit,\r\n
\r\n
George Marina Hilversum.\r\n";
        $headers = "From: Admin@GeorgeMarina.nl";
        $headers = "MIME-version1.0\r\n";
        $headers .="Content-type:text; charset=UTF-8\r\n";

        mail($to, $subject, $message, $headers);
    } else {
        echo "incorrect email";
        header("location: http://www.skrtskrt.org/am1x-vegetablejuice/booking.php");
        die();
    }
?>

<html lang="en">
<head>
	<meta charset="utf-8" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>
	<link href='https://fonts.googleapis.com/css?family=Lato:300,400|Montserrat:700' rel='stylesheet' type='text/css'>
	<style>
		@import url(//cdnjs.cloudflare.com/ajax/libs/normalize/3.0.1/normalize.min.css);
		@import url(//maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css);
	</style>
	<link rel="stylesheet" href="https://2-22-4-dot-lead-pages.appspot.com/static/lp918/min/default_thank_you.css">
	<script src="https://2-22-4-dot-lead-pages.appspot.com/static/lp918/min/jquery-1.9.1.min.js"></script>
	<script src="https://2-22-4-dot-lead-pages.appspot.com/static/lp918/min/html5shiv.js"></script>
</head>
<body>
	<header class="site-header" id="header">
		<h1 class="site-header__title" data-lead-id="site-header-title">THANK YOU</h1>
	</header>

	<div class="main-content">
		<p class="main-content__body" data-lead-id="main-content-body">Thank you for making a reservation at George Marina Hilversum. We will send you an email confirming your reservation. At George Marina, we'll rock your boat!</p>        
        <img src="./img/sendemail.png" style="width: 30%; height:50%;">
	</div>

    <input type="submit" class="submit" value="BACK TO THE HOMEPAGE" style="background-color: #828282; width:20%;height:8%;">   

    
</body>
</html>